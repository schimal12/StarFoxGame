//Erick Alan Cervantes A01215567
//Sebastian Chimal Montes de Oca A01214839

#define WINDOW_WIDTH 600
#define WINDOW_HEIGHT 600
#define WORLD_SIZE 5
#define POINT_SIZE 10
#define RADIUS 0.6
#define ENEMY_RATE 2000
#define MAX_BULLET 100;
#define _USE_MATH_DEFINES
#define DEBUG true
#define SPACEBAR 32

#include "irrKlang.h"
#include <stdio.h>
#include <stdarg.h>
#include<iostream>
#include <cmath>
#include <math.h>
#include <stdlib.h>
#include "SOIL.h"
#include "glm.h"
#include <time.h>
#include <algorithm>
using namespace std;
using namespace irrklang;
#pragma comment(lib, "irrKlang.lib")

#ifdef _WIN32
#include "glut.h"
#elif __APPLE__
#include <GLUT/GLUT.h>
#endif

void Init();
void Display();
void Reshape();

//Entrega 1

typedef struct Context {
    GLboolean AK = false;
    GLboolean WK = false;
    GLboolean SK = false;
    GLboolean DK = false;
    GLboolean FIRE = false;
    GLfloat SENSITIVITY = 6;
    GLfloat T_FIRE = 0;
} Context;

typedef struct State {
    GLfloat *T;
    GLfloat *R;
} State;


typedef struct ParallaxLayer {
    char* texture;
    GLint texID;
    GLdouble pace;
    GLdouble duration;
} ParallaxLayer;

typedef struct Parallax {
    ParallaxLayer* layers;
    GLint size;
} Parallax;

typedef struct Weapon {
    State state;
    GLint ammunition = -1;
    GLint magazine = -1;
    GLint rate;
} Weapon;

typedef struct Animation {
    GLfloat *start;
    GLfloat *end;
};

typedef struct Bullet {
    State state;
    Animation T;
    Animation R;
    GLfloat collider;
    GLfloat frames;
    GLfloat frame = 0;
    GLint activo = 0;
} Bullet;

typedef struct Player {
    Context context;
    State state;
    Weapon weapon;
    char* model;
    GLMmodel* modID;
    GLfloat collider;
} Player;

typedef struct Enemy {
    State state;
    char* model;
    Animation T;
    GLMmodel* modID;
    GLfloat collider;
    GLfloat frames;
    GLfloat frame = 0;
    GLboolean active = true;
    GLint activo = 0;
}Enemigo;

typedef struct EnemySpaceShip{
    State state;
    char* model;
    Animation T;
    GLMmodel* modID;
    GLfloat collider;
    GLfloat frames;
    GLfloat frame = 0;
    GLboolean active = true;
    GLint bulletsNum = 0;
    Bullet *bulletsS;
    GLint danho = 0;
    GLint activo = 0;
    GLint contar = 0;
} EnemigoNave;

typedef struct World {
    EnemySpaceShip *enemiesS;
    Enemy *enemies;
    GLint enemiesN = 0;
    GLint enemiesNN = 0;
    Bullet *bullets;
    Bullet *bulletsS;
    GLint bulletsN = 0;
    GLint bulletsNN = 0;
    GLfloat enemyTime =ENEMY_RATE;
    GLfloat enemyTimes = ENEMY_RATE;
};

Parallax parallax;
Player player;
World world;
Enemy rock;
EnemySpaceShip enemigoSpace;

GLfloat lightT1P[] = { 0.0,0.0,WORLD_SIZE*1.8 };

GLfloat MOVEX = 0.0;
GLfloat MOVEY = 0.0;

GLfloat white[] = { 1.0,1.0,1.0,1.0 };
GLfloat dgray[] = { 0.1,0.1,0.1,1.0 };

GLfloat colorT1[] = { 0.13,0.59,0.95 };
GLfloat colorT1C[] = { 0.49,0.54,0.96 };

GLdouble deltaTime = 0;
GLdouble oldTime = 0;

GLuint B;
GLuint perder;

GLint powerup = 0;
GLint estado = 0;

GLboolean arriba = false;
GLint puntuacionTotal = 0;

void initParallaxFrames() {
    GLint FRAMES = 3;
    parallax.layers = (ParallaxLayer *)malloc(sizeof(ParallaxLayer)*FRAMES);
    parallax.size = FRAMES;
    
    ParallaxLayer layer0;
    char name0[] = "Stars.png";
    layer0.texture = name0;
    layer0.pace = 0.0;
    layer0.texID = -1;
    layer0.duration = 10000.0;
    parallax.layers[0] = layer0;
    
    ParallaxLayer layer1;
    char name1[] = "Transparent.png";
    layer1.texture = name1;
    layer1.pace = 0.0;
    layer1.texID = -1;
    layer1.duration = 10000.0 / 2;
    parallax.layers[1] = layer1;
    
    ParallaxLayer layer2;
    char name2[] = "Transparent.png";
    layer2.texture = name2;
    layer2.pace = 0.0;
    layer2.texID = -1;
    layer2.duration = 10000.0 / 4;
    parallax.layers[2] = layer2;
    
    
    for (int cont = 0; cont < FRAMES; cont += 1) {
        parallax.layers[cont].texID = SOIL_load_OGL_texture(
                                                            parallax.layers[cont].texture,
                                                            SOIL_LOAD_AUTO,
                                                            SOIL_CREATE_NEW_ID,
                                                            SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                                                            );
    }
}

void  bulletState(){
    glDisable(GL_TEXTURE_2D);
    glDisable(GL_LIGHTING);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glTranslated(0, -WORLD_SIZE, 0.2);
    glScalef(WORLD_SIZE-((world.bulletsN+powerup)/50),1.0,1.0);
    glutSolidCube(1);
}

void InsertarTexto(float x, float y,const char *string){
    const char *c;
    glRasterPos2f(x, y);
    for (c=string; *c != '\0'; c++) {
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *c);
    }
}

void textoPuntuacion(){
    glDisable(GL_TEXTURE_2D);
    glDisable(GL_LIGHTING);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glColor3f(0.0, 0.0, 1.0);
    
    
    char integer_string[128];
    int integer = puntuacionTotal;
    
    sprintf(integer_string, "%d", integer);
    
    char other_string[64] = "Puntuacion Total: ";
    
    strcat(other_string, integer_string);
    
    InsertarTexto(-4,4,other_string);
    glColor4f(1.0, 1.0, 1.0, 1.0);
}


void loadModels() {
    char nameP[] = "menu_arwing.obj";
    player.model = nameP;
    player.modID = glmReadOBJ(player.model);
    player.collider = RADIUS;
    
    char nameE[] = "Magma2.obj";
    rock.model = nameE;
    rock.modID = glmReadOBJ(rock.model);
    rock.collider = RADIUS;
    
    char nameS[] = "SpaceShip.obj";
    enemigoSpace.model = nameS;
    enemigoSpace.modID = glmReadOBJ(player.model);
    player.collider = RADIUS;
    
}

void initPlayer() {
    player.state.T = (GLfloat *)malloc(sizeof(GLfloat) * 3);
    player.state.T[0] = -(WORLD_SIZE - (-WORLD_SIZE + RADIUS * 3.5));
    player.state.T[1] = 0.0;
    player.state.T[2] = -0.5;
    
    player.state.R = (GLfloat *)malloc(sizeof(GLfloat) * 3);
    player.state.R[0] = 0.0;
    player.state.R[1] = 90.0;
    player.state.R[2] = 0.0;
    
    player.weapon.state.T = (GLfloat *)malloc(sizeof(GLfloat) * 3);
    player.weapon.state.T[0] = 0.6;
    player.weapon.state.T[1] = -0.05;
    player.weapon.state.T[2] = 0.0;
    
    player.weapon.rate = 10;
}

void Init()
{
    
    
    
    glClearColor(0.007, 0.003, 0.07, 1);
    
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    
    initParallaxFrames();
    loadModels();
    
    initPlayer();
    
    B = SOIL_load_OGL_texture(
                              "Blue.png",
                              SOIL_LOAD_AUTO,
                              SOIL_CREATE_NEW_ID,
                              SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                              );
    perder =                        SOIL_load_OGL_texture(
                                                        "Stars.png",
                                                        SOIL_LOAD_AUTO,
                                                        SOIL_CREATE_NEW_ID,
                                                        SOIL_FLAG_MIPMAPS | SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
                                                        );
    
    glEnable(GL_LIGHTING);
    glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE);
    glEnable(GL_LIGHT0);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, white);
    glLightfv(GL_LIGHT0, GL_SPECULAR, white);
    glLightfv(GL_LIGHT0, GL_POSITION, lightT1P);
    glLightfv(GL_LIGHT1, GL_AMBIENT, white);
}

GLdouble* toWorldCoordinates(int x, int y) {
    GLdouble* res = (GLdouble *)malloc(sizeof(GLdouble) * 3);
    res[0] = ((GLdouble)(x - 250) / 250) + (-1)*MOVEX;
    res[1] = ((GLdouble)(-1)*(y - 250) / 250) + MOVEY;
    res[2] = 0;
    return res;
}

int* screenCoordinate(GLfloat* point) {
    int* res = (int *)malloc(sizeof(int) * 2);
    GLdouble TEMPX = point[0] / WORLD_SIZE;
    GLdouble TEMPY = point[1] / WORLD_SIZE;
    int WIDTH = WINDOW_WIDTH / 2;
    int HEIGHT = WINDOW_HEIGHT / 2;
    
    
    res[0] = (TEMPX * WIDTH) + WIDTH;
    res[1] = ((1 - TEMPY) * HEIGHT);
    
    return res;
}

GLfloat* getDirectionVector() {
    GLfloat* vector = (GLfloat *)malloc(sizeof(GLfloat) * 2);
    vector[0] = 0.0;
    vector[1] = 0.0;
    
    if (player.context.AK) {
        vector[0] -= 1.0;
    }
    if (player.context.WK) {
        vector[1] += 1.0;
    }
    if (player.context.SK) {
        vector[1] -= 1.0;
    }
    if (player.context.DK) {
        vector[0] += 1.0;
    }
    
    GLfloat	vecm = sqrt(vector[0] * vector[0] + vector[1] * vector[1]);
    if (vecm != 0.0) {
        vector[0] /= vecm;
        vector[1] /= vecm;
        
    }
    GLfloat rate = player.context.SENSITIVITY*deltaTime*0.001;
    vector[0] *= rate;
    vector[1] *= rate;
    
    return vector;
}


void generateSpaceE(){
    srand(glutGet(GLUT_ELAPSED_TIME));
    if (world.enemyTimes >= ENEMY_RATE+500) {
        EnemySpaceShip *list = (EnemySpaceShip *)malloc(sizeof(EnemySpaceShip)*(world.enemiesNN));
        GLint activeEnemies = 0;
        for (int cont = 0; cont < world.enemiesNN; cont += 1) {
            if (world.enemiesS[cont].state.T[0] > (-WORLD_SIZE) && world.enemiesS[cont].active) {
                activeEnemies += 1;
            } else {
                world.enemiesS[cont].active = false;
            }
            list[cont] = world.enemiesS[cont];
        }
        
        free(world.enemiesS);
        world.enemiesS = (EnemySpaceShip *)malloc(sizeof(EnemySpaceShip)*(activeEnemies + 1));
        GLint con = 0;
        for (int cont = 0; cont < world.enemiesNN; cont += 1) {
            if (list[cont].active) {
                world.enemiesS[con] = list[cont];
                con += 1;
            }
        }
        free(list);
        
        world.enemiesNN = activeEnemies;
        
        GLfloat zone = (rand() % (WORLD_SIZE * 2)) - 0.9;
        
        world.enemiesS[world.enemiesNN].collider = RADIUS;
        world.enemiesS[world.enemiesNN].model = enemigoSpace.model;
        world.enemiesS[world.enemiesNN].modID = enemigoSpace.modID;
        world.enemiesS[world.enemiesNN].active = true;
        world.enemiesS[world.enemiesNN].frame = 0.0;
        world.enemiesS[world.enemiesNN].frames = 3000.0;
        
        world.enemiesS[world.enemiesNN].T.start = (GLfloat *)malloc(sizeof(GLfloat) * 3);
        world.enemiesS[world.enemiesNN].T.start[0] = WORLD_SIZE;
        world.enemiesS[world.enemiesNN].T.start[1] = (((zone / (WORLD_SIZE * 2)) - (WORLD_SIZE / 10.0)) * 2.0 * (WORLD_SIZE - 1)) - RADIUS*0.7;
        world.enemiesS[world.enemiesNN].T.start[2] = -0.5;
        
        zone = (rand() % (WORLD_SIZE * 2)) + -0.4;
        
        world.enemiesS[world.enemiesNN].T.end = (GLfloat *)malloc(sizeof(GLfloat) * 3);
        world.enemiesS[world.enemiesNN].T.end[0] = -WORLD_SIZE;
        world.enemiesS[world.enemiesNN].T.end[1] = (((zone / (WORLD_SIZE * 2)) - (WORLD_SIZE / 10.0)) * 2.0 * (WORLD_SIZE - 1)) - RADIUS*0.7;
        world.enemiesS[world.enemiesNN].T.end[2] = -0.5;
        
        world.enemiesS[world.enemiesNN].state.T = (GLfloat *)malloc(sizeof(GLfloat) * 3);
        world.enemiesS[world.enemiesNN].state.T[0] = world.enemiesS[world.enemiesNN].T.start[0];
        world.enemiesS[world.enemiesNN].state.T[1] = world.enemiesS[world.enemiesNN].T.start[1];
        world.enemiesS[world.enemiesNN].state.T[2] = world.enemiesS[world.enemiesNN].T.start[2];
        
        world.enemiesS[world.enemiesNN].state.R = (GLfloat *)malloc(sizeof(GLfloat) * 3);
        world.enemiesS[world.enemiesNN].state.R[0] = 0.0;
        
        world.enemiesS[world.enemiesNN].danho = 0;
        world.enemiesS[world.enemiesNN].activo = 0;
        world.enemiesS[world.enemiesNN].contar = 0;
        world.enemiesNN += 1;
        world.enemyTimes = 0.0;
    } else {
        world.enemyTimes += deltaTime;
    }

}

void generateEnemies() {
    srand(glutGet(GLUT_ELAPSED_TIME));
    if (world.enemyTime >= ENEMY_RATE) {
        Enemy *list = (Enemy *)malloc(sizeof(Enemy)*(world.enemiesN));
        GLint activeEnemies = 0;
        for (int cont = 0; cont < world.enemiesN; cont += 1) {
            if (world.enemies[cont].state.T[0] > (-WORLD_SIZE) && world.enemies[cont].active) {
                activeEnemies += 1;
            } else {
                world.enemies[cont].active = false;
            }
            list[cont] = world.enemies[cont];
        }
        
        free(world.enemies);
        world.enemies = (Enemy *)malloc(sizeof(Enemy)*(activeEnemies + 1));
        GLint con = 0;
        for (int cont = 0; cont < world.enemiesN; cont += 1) {
            if (list[cont].active) {
                world.enemies[con] = list[cont];
                con += 1;
            }
        }
        free(list);
        
        world.enemiesN = activeEnemies;
        
        GLfloat zone = (rand() % (WORLD_SIZE * 2)) + 1;
        
        world.enemies[world.enemiesN].collider = RADIUS;
        world.enemies[world.enemiesN].model = rock.model;
        world.enemies[world.enemiesN].modID = rock.modID;
        world.enemies[world.enemiesN].active = true;
        world.enemies[world.enemiesN].frame = 0.0;
        world.enemies[world.enemiesN].frames = 3000.0;
        
        world.enemies[world.enemiesN].T.start = (GLfloat *)malloc(sizeof(GLfloat) * 3);
        world.enemies[world.enemiesN].T.start[0] = WORLD_SIZE;
        world.enemies[world.enemiesN].T.start[1] = (((zone / (WORLD_SIZE * 2)) - (WORLD_SIZE / 10.0)) * 2.0 * (WORLD_SIZE - 1)) - RADIUS*0.7;
        world.enemies[world.enemiesN].T.start[2] = -0.5;
        
        zone = (rand() % (WORLD_SIZE * 2)) + 1;
        
        world.enemies[world.enemiesN].T.end = (GLfloat *)malloc(sizeof(GLfloat) * 3);
        world.enemies[world.enemiesN].T.end[0] = -WORLD_SIZE;
        world.enemies[world.enemiesN].T.end[1] = (((zone / (WORLD_SIZE * 2)) - (WORLD_SIZE / 10.0)) * 2.0 * (WORLD_SIZE - 1)) - RADIUS*0.7;
        world.enemies[world.enemiesN].T.end[2] = -0.5;
        
        world.enemies[world.enemiesN].state.T = (GLfloat *)malloc(sizeof(GLfloat) * 3);
        world.enemies[world.enemiesN].state.T[0] = world.enemies[world.enemiesN].T.start[0];
        world.enemies[world.enemiesN].state.T[1] = world.enemies[world.enemiesN].T.start[1];
        world.enemies[world.enemiesN].state.T[2] = world.enemies[world.enemiesN].T.start[2];
        
        world.enemies[world.enemiesN].state.R = (GLfloat *)malloc(sizeof(GLfloat) * 3);
        world.enemies[world.enemiesN].state.R[0] = 0.0;
        world.enemies[world.enemiesN].activo = 0;
        
        world.enemiesN += 1;
        world.enemyTime = 0.0;
    } else {
        world.enemyTime += deltaTime;
    }
}

GLdouble linearCurve(GLfloat time, GLfloat start, GLfloat end, GLfloat duration) {
    return (end - start)*(time) / duration + start;
}


void drawCollisionSphere(GLfloat x, GLfloat y, GLfloat z, GLfloat size) {
    glDisable(GL_TEXTURE_2D);
    glDisable(GL_LIGHTING);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glTranslatef(x, y, z);
    glRotated(90, 0, 1, 0);
    glutWireSphere(size, 10, 10);
    glColor3f(1.0, 1.0, 1.0);
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_LIGHTING);
}

void drawSpaceE(){
    for (int cont = 0; cont < world.enemiesNN; cont += 1) {
        if(world.enemiesS[cont].activo == 0){
            glDisable(GL_LIGHTING);
            glEnable(GL_TEXTURE_2D);
            glMatrixMode(GL_MODELVIEW);
            glLoadIdentity();
            world.enemiesS[cont].state.T[0] = linearCurve(world.enemiesS[cont].frame, world.enemiesS[cont].T.start[0], world.enemiesS[cont].T.end[0], world.enemiesS[cont].frames);
            world.enemiesS[cont].state.T[1] = linearCurve(world.enemiesS[cont].frame, world.enemiesS[cont].T.start[1], world.enemiesS[cont].T.end[1], world.enemiesS[cont].frames);
            glTranslated(world.enemiesS[cont].state.T[0], world.enemiesS[cont].state.T[1], world.enemiesS[cont].state.T[2]);
            glRotated(-90,0,1,0);
            glmDraw(world.enemiesS[cont].modID, GLM_TEXTURE | GLM_SMOOTH | GLM_MATERIAL);
            world.enemiesS[cont].state.R[0] += 100.0*(deltaTime / 1000.0);
            world.enemiesS[cont].frame += 1.0 * deltaTime;
            if(world.enemiesS[cont].state.T[0]<-5){
                world.enemiesS[cont].activo = 1;
            }
            if (DEBUG) {
                glColor3f(0.0, 0.0, 1.0);
                drawCollisionSphere(world.enemiesS[cont].state.T[0], world.enemiesS[cont].state.T[1], world.enemiesS[cont].state.T[2], world.enemiesS[cont].collider);
            }
            glEnable(GL_LIGHTING);
        }
    }
}

void drawEnemies() {
    for (int cont = 0; cont < world.enemiesN; cont += 1) {
        if(world.enemies[cont].activo == 0){
            glDisable(GL_LIGHTING);
            glEnable(GL_TEXTURE_2D);
            glMatrixMode(GL_MODELVIEW);
            glLoadIdentity();
            world.enemies[cont].state.T[0] = linearCurve(world.enemies[cont].frame, world.enemies[cont].T.start[0], world.enemies[cont].T.end[0], world.enemies[cont].frames);
            world.enemies[cont].state.T[1] = linearCurve(world.enemies[cont].frame, world.enemies[cont].T.start[1], world.enemies[cont].T.end[1], world.enemies[cont].frames);
            if( world.enemies[cont].state.T[0]<-5){
                world.enemies[cont].activo = 1;
            }
            glTranslated(world.enemies[cont].state.T[0], world.enemies[cont].state.T[1], world.enemies[cont].state.T[2]);
            glRotated(world.enemies[cont].state.R[0],1,1,1);
            glmDraw(world.enemies[cont].modID, GLM_TEXTURE | GLM_SMOOTH | GLM_MATERIAL);
            world.enemies[cont].state.R[0] += 100.0*(deltaTime / 1000.0);
            world.enemies[cont].frame += 1.0 * deltaTime;
            
            double distancia = sqrt(pow(player.state.T[0] - world.enemies[cont].state.T[0], 2)+pow(player.state.T[1] - world.enemies[cont].state.T[1], 2)+pow(player.state.T[2] - world.enemies[cont].state.T[2], 2));
            
            if(distancia < RADIUS){
                estado = 2;
            }
            if (DEBUG) {
                glColor3f(0.0, 0.0, 1.0);
                drawCollisionSphere(world.enemies[cont].state.T[0], world.enemies[cont].state.T[1], world.enemies[cont].state.T[2], world.enemies[cont].collider);
            }
            glEnable(GL_LIGHTING);
   
        }
    }
}


void drawPlayer() {
    glTranslatef(player.state.T[0], player.state.T[1], player.state.T[2]);
    glRotated(player.state.R[1], 0, 1, 0);
    glRotated(player.state.R[0], 1, 0, 0);
    glRotated(player.state.R[2], 0, 0, 1);
    
    glmDraw(player.modID, GLM_TEXTURE | GLM_SMOOTH | GLM_MATERIAL);
    if (DEBUG) {
        glColor3f(0.0, 0.0, 1.0);
        drawCollisionSphere(player.state.T[0], player.state.T[1], player.state.T[2], player.collider);
        glColor3f(1.0, 1.0, 0.0);
        drawCollisionSphere(player.state.T[0]+player.weapon.state.T[0], player.state.T[1] + player.weapon.state.T[1], player.state.T[2] + +player.weapon.state.T[2], 0.1);
    }
}

void drawBullets() {
    for(int cont1=0;cont1<world.enemiesNN;cont1+=1){
        for (int cont = 0; cont < world.bulletsN; cont += 1) {
            if(world.bullets[cont].activo == 0){
                glDisable(GL_LIGHTING);
                glDisable(GL_TEXTURE_2D);
                glMatrixMode(GL_MODELVIEW);
                glLoadIdentity();
                world.bullets[cont].state.T[0] = linearCurve(world.bullets[cont].frame, world.bullets[cont].T.start[0], world.bullets[cont].T.end[0], world.bullets[cont].frames);
                glTranslated(world.bullets[cont].state.T[0], world.bullets[cont].state.T[1], world.bullets[cont].state.T[2]);
                glColor3f(1.0, 1.0, 0.0);
                glutSolidSphere(0.05, 20, 20);
                glColor3f(1.0, 1.0, 1.0);
                
                double distancia = sqrt(pow(world.bullets[cont].state.T[0] - world.enemiesS[cont1].state.T[0], 2)+pow(world.bullets[cont].state.T[1] - world.enemiesS[cont1].state.T[1], 2)+pow(world.bullets[cont].state.T[2] - world.enemiesS[cont1].state.T[2], 2));
                
                if(distancia<RADIUS){
                   
                    world.enemiesS[cont1].danho+=1;
                }
                if(world.enemiesS[cont1].danho>5){
                     printf("Choque a enemigo: %i\n",cont1);
                    world.enemiesS[cont1].activo = 1;
                    if(world.enemiesS[cont1].contar == 0){
                        puntuacionTotal+=1;
                        world.enemiesS[cont1].contar = 1;
                    }
                }
            
                if(world.bullets[cont].state.T[0]>5){
                    world.bullets[cont].activo = 1;
                }
                if (DEBUG) {
                    drawCollisionSphere(world.bullets[cont].state.T[0], world.bullets[cont].state.T[1], world.bullets[cont].state.T[2], world.bullets[cont].collider);
                }
                world.bullets[cont].frame += 1 * deltaTime;
                glEnable(GL_TEXTURE_2D);
                glEnable(GL_LIGHTING);
   
            }
        }
    }
}


void movementContext() {
    glDisable(GL_LIGHTING);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    
    if (player.context.WK) {
        player.state.R[0] = -20;
    }
    else {
        if (player.context.SK) {
            player.state.R[0] = 20;
        }
        else {
            player.state.R[0] = 0.0;
        }
    }
    
    GLfloat *DV = getDirectionVector();
    player.state.T[0] += DV[0];
    player.state.T[1] += DV[1];
    player.state.T[0] = max(-1.0*WORLD_SIZE + RADIUS*2.5, (double)player.state.T[0]);
    player.state.T[0] = min(1.0*WORLD_SIZE - RADIUS*2.5, (double)player.state.T[0]);
    player.state.T[1] = max(-1.0*WORLD_SIZE + RADIUS*2.5, (double)player.state.T[1]);
    player.state.T[1] = min(1.0*WORLD_SIZE - RADIUS*2.5, (double)player.state.T[1]);
}

void fireContext() {
    if (player.context.FIRE && world.bulletsN < 500){
        Bullet *list = (Bullet *)malloc(sizeof(Bullet)*(world.bulletsN));
        for (int cont = 0; cont < world.bulletsN; cont += 1) {
            list[cont] = world.bullets[cont];
        }
        free(world.bullets);
        world.bullets = (Bullet *)malloc(sizeof(Bullet)*(world.bulletsN + 1));
        for (int cont = 0; cont < world.bulletsN; cont += 1) {
            world.bullets[cont] = list[cont];
        }
        free(list);
        
        world.bullets[world.bulletsN].collider = 0.1;
        world.bullets[world.bulletsN].frames = 600.0 * (WORLD_SIZE - player.state.T[0] + player.weapon.state.T[0]) / (WORLD_SIZE - (-WORLD_SIZE + RADIUS * 3.5));
        world.bullets[world.bulletsN].frame = 0.0;
        
        world.bullets[world.bulletsN].T.start = (GLfloat *)malloc(sizeof(GLfloat) * 3);
        world.bullets[world.bulletsN].T.start[0] = player.state.T[0] + player.weapon.state.T[0];
        world.bullets[world.bulletsN].T.start[1] = player.state.T[1] + player.weapon.state.T[1];
        world.bullets[world.bulletsN].T.start[2] = player.state.T[2] + player.weapon.state.T[2];
        
        
        world.bullets[world.bulletsN].T.end = (GLfloat *)malloc(sizeof(GLfloat) * 3);
        world.bullets[world.bulletsN].T.end[0] = WORLD_SIZE;
        world.bullets[world.bulletsN].T.end[1] = player.state.T[1] + player.weapon.state.T[1];
        world.bullets[world.bulletsN].T.end[2] = player.state.T[2] + player.weapon.state.T[2];
        
        world.bullets[world.bulletsN].state.T = (GLfloat *)malloc(sizeof(GLfloat) * 3);
        world.bullets[world.bulletsN].state.T[0] = 0;
        world.bullets[world.bulletsN].state.T[1] = world.bullets[world.bulletsN].T.start[1];
        world.bullets[world.bulletsN].state.T[2] = world.bullets[world.bulletsN].T.start[2];
        
        world.bullets[world.bulletsN].activo = 0;
        
        world.bulletsN += 1;
        player.context.FIRE = false;
    }
}

void processContext() {
    
    movementContext();
    
    drawPlayer();
    
    fireContext();
    
    drawBullets();
    
    
}

void updateDeltaTime() {
    GLdouble newTime = glutGet(GLUT_ELAPSED_TIME);
    deltaTime = newTime - oldTime;
    oldTime = newTime;
}

void showParallaxLayers() {
    glEnable(GL_TEXTURE_2D);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glDisable(GL_LIGHTING);
    glClear(GL_DEPTH_BUFFER_BIT);
    
    for (int cont = 0; cont < parallax.size; cont += 1) {
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        
        ParallaxLayer layer = parallax.layers[cont];
        parallax.layers[cont].pace = parallax.layers[cont].pace > parallax.layers[cont].duration ? 0.0 : parallax.layers[cont].pace;
        
        glTranslated((-(WORLD_SIZE)* 2 * (parallax.layers[cont].pace / parallax.layers[cont].duration)), 0, 0);
        parallax.layers[cont].pace += deltaTime;
        
        GLfloat DEPTH = 1 - cont*0.1;
        
        glBindTexture(GL_TEXTURE_2D, layer.texID);
        glBegin(GL_QUADS);
        glTexCoord2f(0.0, 1.0);
        glVertex3f(-WORLD_SIZE, WORLD_SIZE, DEPTH);
        
        glTexCoord2f(0.0, 0.0);
        glVertex3f(-WORLD_SIZE, -WORLD_SIZE, DEPTH);
        
        glTexCoord2f(1.0, 0.0);
        glVertex3f(WORLD_SIZE, -WORLD_SIZE, DEPTH);
        
        glTexCoord2f(1.0, 1.0);
        glVertex3f(WORLD_SIZE, WORLD_SIZE, DEPTH);
        glEnd();
        
        glBegin(GL_QUADS);
        glTexCoord2f(0.0, 1.0);
        glVertex3f(WORLD_SIZE, WORLD_SIZE, DEPTH);
        
        glTexCoord2f(0.0, 0.0);
        glVertex3f(WORLD_SIZE, -WORLD_SIZE, DEPTH);
        
        glTexCoord2f(1.0, 0.0);
        glVertex3f(WORLD_SIZE + WORLD_SIZE * 2, -WORLD_SIZE, DEPTH);
        
        glTexCoord2f(1.0, 1.0);
        glVertex3f(WORLD_SIZE + WORLD_SIZE * 2, WORLD_SIZE, DEPTH);
        glEnd();
        
        glClear(GL_DEPTH_BUFFER_BIT);
    }
    
}

GLdouble FOVY(GLdouble size, GLdouble dist) {
    GLdouble theta = 2.0*atan((size / 2.0) / dist);
    return(180.0*theta / M_PI);
}

void orthoCamera() {
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-WORLD_SIZE, WORLD_SIZE, -WORLD_SIZE, WORLD_SIZE, -WORLD_SIZE, WORLD_SIZE);
}

void perspectiveCamera() {
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(FOVY(WORLD_SIZE, WORLD_SIZE), 1.0, 0.1, 10 * WORLD_SIZE);
    gluLookAt(
              0, 0, WORLD_SIZE*1.55,
              0, 0, -1,
              0, 1, 0
              );
}

void Display()
{
    //ISoundEngine* starfox1 = createIrrKlangDevice();
    updateDeltaTime();
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    if(estado == 0){
       // starfox1->play2D("starfox.ogg", true);
        glLoadIdentity();
        showParallaxLayers();
        orthoCamera();
        glDisable(GL_TEXTURE_2D);
        glDisable(GL_LIGHTING);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        glColor3f(0.0, 0.0, 1.0);
        InsertarTexto(-4,4,"Las teclas son las siguientes");
        InsertarTexto(-4,3,"W -> Adelante");
        InsertarTexto(-4,2,"S -> Atras");
        InsertarTexto(-4,1,"A -> Izquierda");
        InsertarTexto(-4,0,"D -> Derecha");
        InsertarTexto(-4,-1,"Space -> Disparo");
        InsertarTexto(-4,-2,"Aprieta cualquier tecla para jugar");
    }else{
        if(estado == 1){
            glColor4f(1.0, 1.0, 1.0, 1.0);
            orthoCamera();
            showParallaxLayers();

            orthoCamera();
            textoPuntuacion();
            bulletState();
            perspectiveCamera();
            processContext();
            generateEnemies();
            drawEnemies();
            generateSpaceE();
            drawSpaceE();
        }else{
            glLoadIdentity();
            showParallaxLayers();
            orthoCamera();
            glDisable(GL_TEXTURE_2D);
            glDisable(GL_LIGHTING);
            glMatrixMode(GL_MODELVIEW);
            glLoadIdentity();
            glColor3f(1.0, 0.0, 0.0);
            InsertarTexto(-1,0,"Has Perdido");
        }
    }
    
    /*orthoCamera();
     glDisable(GL_TEXTURE_2D);
     glDisable(GL_LIGHTING);
     glMatrixMode(GL_MODELVIEW);
     glLoadIdentity();
     glTranslated(0, -WORLD_SIZE, 0.5);
     glScaled(WORLD_SIZE, 1, 1);
     glColor4f(0.0,1.0,0.0,0.2);
     glutSolidCube(1);
     
     glLoadIdentity();
     glTranslated(0, WORLD_SIZE, 0.2);
     glScaled(WORLD_SIZE, 1.0, 1);
     glColor4f(1.0, 1.0, 0.0, 0.5);
     glutSolidCube(1);
     glColor3f(1.0, 1.0, 1.0);*/
    
    glutSwapBuffers();
    glutPostRedisplay();
    
}

void Reshape(int w, int h)
{
    glViewport(0, 0, w, h);
    
}

void keyboardController(unsigned char key, int x, int y) {
    
    
    if(estado==0){
        estado = 1;
    }else{
        switch (key)
        {
            case 'a':case 'A':
                player.context.AK = true;
                break;
            case 'w':case 'W':
                player.context.WK = true;
                break;
            case 's':case 'S':
                player.context.SK = true;
                break;
            case 'd':case 'D':
                player.context.DK = true;
                break;
            case SPACEBAR:
                player.context.FIRE = true;
                break;
            default:
                
                break;
        }
    }
}

void keyboardRelease(unsigned char key, int x, int y) {
    //cout << "Release " << key << " " << x << " " << y << "\n";
    switch (key)
    {
        case 'a':case 'A':
            player.context.AK = false;
            break;
        case 'w':case 'W':
            player.context.WK = false;
            break;
        case 's':case 'S':
            player.context.SK = false;
            break;
        case 'd':case 'D':
            player.context.DK = false;
            break;
        default:
            
            break;
    }
}


int main(int artcp, char **argv)
{
    glutInit(&artcp, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
    glutInitWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);
    glutCreateWindow("Avance 3");
    glutKeyboardUpFunc(keyboardRelease);
    glutKeyboardFunc(keyboardController);
    glutDisplayFunc(Display);
    glutReshapeFunc(Reshape);
    Init();
    oldTime = glutGet(GLUT_ELAPSED_TIME);
    glutMainLoop();
    return 0;
    
}